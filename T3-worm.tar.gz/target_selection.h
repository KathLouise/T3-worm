#ifndef _TARGETSELECTION_H
#define _TARGETSELECTION_H

void randomLine(char **lines, char **param, int numberLines);
void target_selection(char **param);

#endif
