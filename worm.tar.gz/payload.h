#ifndef _PAYLOAD_H
#define _PAYLOAD_H

void printcow();
void payload();

#endif
